<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Pavement Tiles" tilewidth="16" tileheight="16" tilecount="33" columns="11">
 <image source="../../TileSet/Tiles/Pavement Tiles.png" width="176" height="48"/>
</tileset>
