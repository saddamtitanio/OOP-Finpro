<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Road Tiles" tilewidth="16" tileheight="16" tilecount="33" columns="11">
 <image source="../../TileSet/Tiles/Road Tiles.png" width="176" height="48"/>
</tileset>
